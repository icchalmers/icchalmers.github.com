/*******************************************************************************
* File Name: LEDPin.h  
* Version 2.10
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_LEDPin_ALIASES_H) /* Pins LEDPin_ALIASES_H */
#define CY_PINS_LEDPin_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define LEDPin_0		(LEDPin__0__PC)
#define LEDPin_0_PS		(LEDPin__0__PS)
#define LEDPin_0_PC		(LEDPin__0__PC)
#define LEDPin_0_DR		(LEDPin__0__DR)
#define LEDPin_0_SHIFT	(LEDPin__0__SHIFT)


#endif /* End Pins LEDPin_ALIASES_H */


/* [] END OF FILE */
