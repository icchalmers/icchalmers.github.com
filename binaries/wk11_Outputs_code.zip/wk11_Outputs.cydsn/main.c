/*
 * Author: Iain Chalmers
 * Date: 2015/04/21
 * Copyright: Iain Chalmers 2015
 */

/* =============================================================================
 *
 * This is a program drive a 16x2 chartacter LCD display. It's designed to run
 * on a PCB that I designed. You can find the design files for the board on my 
 * FabAcademy 2015 webpage:
 *
 *     http://fabacademy.org/archives/2015/eu/students/chalmers.iain/week-11-outputs.html
 * 
 * Assuming everything is working OK, you should see "Hello World! on the display
 * =============================================================================
*/

#include <project.h>

#define LCD_ROWS 2
#define LCD_COLUMNS 16

int main()
{
    uint32_t flag = 0;
    
    LCD_Start();
    
    /* Set position for string output to row - 0 column - 0 */
    LCD_Position(0u, 0u);
    
    // Output "Hello World!" message, "Hello" on line 1, "World!" on line 2
    LCD_PrintString("Hello");
    LCD_Position(1u, 0u);
    LCD_PrintString("World!");

    // just sit and flash the LED
    while(1){
        LEDPin_Write(flag);
        flag = !flag;
        CyDelay(500);
    }
}

