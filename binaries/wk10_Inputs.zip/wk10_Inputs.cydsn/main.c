/*
 * Author: Iain Chalmers
 * Date: 2015/04/14
 * Copyright: Iain Chalmers 2015
 */

/* =============================================================================
 *
 * This is a simple program to test CapSense  and the TMP275 temperature sensor.
 * It's setup to run using the PSoC 4 breakout board that I designed. You can 
 * find the design files for the board on my GitHub
 *
 *     https://github.com/icchalmers/FabAcademy_PSoC4_Breakout
 * 
 * Assuming everything is working OK, you should see the LEDs react to the cap
 * sense buttons. Debug information is output on the UART attached to SCB0 (i.e.
 * to the UART used for bootloading). UART is 115200/8-N-1.
 *
 * Button0: Select operation mode.
 *     Mode0 (default): Rainbow Pattern
 *         Button1: Change LED Brightness (remembered across modes)
 *         Button2: Slow down the rainbow speed
 *         Button3: Speed up the rainbow pattern
 * 
 *     Mode1: Temperature Sensing
 *         Button1: Reset maximum/minimum temperature to current reading
 *
 * Note that the "debounce" of the buttons is very crude!
 *
 * I also found that having the string buffer "debugBuffer" as a global for some
 * reason made all the buttons become unresponsive once a state change happened.
 * I gave up finding the underlying issue as not having a debugger made it 
 * incredibly frustrating!
 * =============================================================================
*/
#include <project.h>
#include "stdio.h"

// WS2812 control
#define NUMPIXELS 9
#define COLOURSTEPSIZE 255/NUMPIXELS

// Rainbow pattern speed control
#define DELAY_MIN 30
#define DELAY_MAX 500
#define DELAY_SCALE 80

// TMP275 Control
#define TMP275_ADDRESS 0x0000004F
#define TMP275_UNITSBYTE 1
#define TMP275_FRACTIONBYTE 0
typedef union TMP275_temperature{
    uint8_t byte[2];
    int16_t word;
}TMP275_TEMPERATURE;
TMP275_TEMPERATURE currentTemperature;

// State machine control
typedef void (*functionPointer)();
typedef functionPointer (*stateFunction)();

// State function headers
functionPointer State_Rainbow();
functionPointer State_Temperature();

// Function Headers
void Init();
uint32_t Wheel(uint8_t WheelPos);
void CapSense_Update();
TMP275_TEMPERATURE TMP275_GetTemperature();
void TMP275_Configure(uint8_t config);
uint32_t TempToIntensity(int16_t temperature, int16_t max, int16_t min);
void SW1_ISR(void);

// Macros for CapSense button checking
// Almost certainly a cleaner way to do this as a single macro with a variable...
#define BUTTON0_STATE CapSense_CheckIsWidgetActive(CapSense_SENSOR_BUTTON0__BTN)
#define BUTTON1_STATE CapSense_CheckIsWidgetActive(CapSense_SENSOR_BUTTON1__BTN)
#define BUTTON2_STATE CapSense_CheckIsWidgetActive(CapSense_SENSOR_BUTTON2__BTN)
#define BUTTON3_STATE CapSense_CheckIsWidgetActive(CapSense_SENSOR_BUTTON3__BTN)


int main(){
    stateFunction currentState = State_Rainbow;
    
    Init();  
    while(1){
        CapSense_Update();
        currentState = (stateFunction)(*currentState)();
    }
    
    return 0;
}


void Init(){
    StripLights_Start(); 
    StripLights_Dim(2); // Dim to 25% by default
    ISR_SW1_StartEx(SW1_ISR);
    
    CyGlobalIntEnable;
    
    UART_Debug_Start();
    I2C_Start();
    // 0x06 gives 12-bit resolution, convertion time of 220ms
    TMP275_Configure(0x06);
    CapSense_Start(); // will hang if interrupts disabled!
    CapSense_InitializeAllBaselines();
    LEDPin_Write(0); // LED on
}


functionPointer State_Temperature(){
    uint32_t pixelIntensity;
    static TMP275_TEMPERATURE temperatureMax, temperatureMin;
    static uint32_t firstRun = 1;
    char debugBuffer[50];
    
    // Get a new temperature reading
    currentTemperature = TMP275_GetTemperature();
    
    // Change state on button 0
    if(BUTTON0_STATE){
        // Wait until button is released. Very crude!
        while(BUTTON0_STATE){
            CapSense_Update();
        }
        return (functionPointer)State_Rainbow;
    }
    
    // Resetting the max/min temerature range on button 1
    if(BUTTON1_STATE || firstRun){
        firstRun = 0;
        // Wait until button is released. Very crude!
        while(BUTTON1_STATE){
            CapSense_Update();
        }
        temperatureMax = currentTemperature;
        temperatureMin = currentTemperature;
    }

    // Update max/min temperature based on current reading
    if(temperatureMax.word < currentTemperature.word){
            temperatureMax = currentTemperature;
    }
    if(temperatureMin.word > currentTemperature.word){
            temperatureMin = currentTemperature;
    }
    
    // Update the intensity mapping
    pixelIntensity = TempToIntensity(
        currentTemperature.word, temperatureMax.word, temperatureMin.word);
    
    // Output the intensity to the LEDs
    StripLights_DisplayClear(pixelIntensity);
    while( StripLights_Ready() == 0);
    StripLights_Trigger(1);
    
    // Output debug data to the UART
    sprintf(debugBuffer, 
        "TUnits: %d TFract: %d TTotal %d TMax %d TMin %d PInt %lx\r\n", 
        currentTemperature.byte[TMP275_UNITSBYTE],
        currentTemperature.byte[TMP275_FRACTIONBYTE],
        currentTemperature.word,
        temperatureMax.word,
        temperatureMin.word,
        pixelIntensity);
    UART_Debug_UartPutString(debugBuffer);

    // A 12-bit conversion takes 220ms so a delay of 250ms seems reasonable
    CyDelay(250);
    return (functionPointer)State_Temperature;
}

// Convert a temperature to a red/blue mix based on the range max/min with the 
// current temperature.
uint32_t TempToIntensity(int16_t temperature, int16_t max, int16_t min){
    float rawIntensity;
    uint32_t pixelIntensity;
    
    if(max - min == 0){
        rawIntensity = 128;
    }
    else{
        // scale intensity to range 0 to 255
        rawIntensity = ((float)temperature - (float)min) / 
            ((float)max - (float)min) * (float)255;
    }
    
    // Map the raw intensity so that high in range means more red and low in
    // range means more blue
    pixelIntensity = ((uint32_t)rawIntensity << 8) |
        ((255 - (uint32_t)rawIntensity) << 16);
    
        return pixelIntensity;
}

    
functionPointer State_Rainbow(){
    static uint32_t LEDState = 0;
    static uint32_t LEDCounter = 0;
    static uint32_t counter = 0;
    static uint32_t delayRaw = DELAY_MIN + (DELAY_MAX - DELAY_MIN) / 2;
    static uint32_t LEDBrightness = 2;
    uint32_t pixelNumber;
    char debugBuffer[50];
        
    // flash the dev kit LED as a basic sanity test while in default state
    if(LEDCounter < 150){
        LEDCounter++;
    }
    else{
        LEDCounter = 0;
        LEDState = !LEDState;
        LEDPin_Write(LEDState);
    }
    
    // Switch to temperature mode on button 0 pressed
    if(BUTTON0_STATE){
        while(BUTTON0_STATE){
            CapSense_Update();
        }
        return (functionPointer)State_Temperature;
    }
    
    // Cycle through LED brightness steps on button 1
    if(BUTTON1_STATE){
        while(BUTTON1_STATE){
            CapSense_Update();
        }
        LEDBrightness = (LEDBrightness + 1) % 4;
        StripLights_Dim(LEDBrightness);
    }
    
    // Slow down pattern on button 2
    if(BUTTON2_STATE){
        if(delayRaw < DELAY_MAX) delayRaw++;
    }
    
    // Speed up pattern on button 3
    if(BUTTON3_STATE){
        if(delayRaw > DELAY_MIN) delayRaw--;
    }
    
    // Update the colour of each LED
    for(pixelNumber = 0; pixelNumber < NUMPIXELS; pixelNumber++){
        StripLights_Pixel(
        pixelNumber,
        0,
        Wheel(counter + (pixelNumber * COLOURSTEPSIZE)));
    }
    counter++;
    while( StripLights_Ready() == 0);
    StripLights_Trigger(1);
    CyDelay(delayRaw / DELAY_SCALE);
    
    // Output debug data to the UART
    sprintf(debugBuffer, 
        "Brightness: %ld Delay %ld\r\n", LEDBrightness, delayRaw / DELAY_SCALE);
    UART_Debug_UartPutString(debugBuffer);
    
    return (functionPointer)State_Rainbow;
}


void CapSense_Update(){
    CapSense_UpdateEnabledBaselines();
    CapSense_ScanEnabledWidgets();
    while(CapSense_IsBusy());
}


void TMP275_Configure(uint8_t config){       
    uint8_t txBuff[] = {0x01, 0x00};
    txBuff[1] = config;
    // writing a 01 tells TMP275 to start at configure register
    I2C_I2CMasterWriteBuf(TMP275_ADDRESS,txBuff,2,I2C_I2C_MODE_COMPLETE_XFER);
    while(0==(I2C_I2CMasterStatus() & I2C_I2C_MSTAT_WR_CMPLT));
}


TMP275_TEMPERATURE TMP275_GetTemperature(){
    uint8_t rxBuff[2];
    uint8_t txBuff[] = {0};
    TMP275_TEMPERATURE tempTemperature;
    
    // writing a 0 tells TMP275 to start at temperature register for I2C reads
    I2C_I2CMasterWriteBuf(TMP275_ADDRESS,txBuff,1,I2C_I2C_MODE_COMPLETE_XFER);
    while(0==(I2C_I2CMasterStatus() & I2C_I2C_MSTAT_WR_CMPLT));
    
    // Now we can read the two bytes that make up the temperature.
    // The first byte is the MSB
    I2C_I2CMasterReadBuf(TMP275_ADDRESS,rxBuff,2,I2C_I2C_MODE_COMPLETE_XFER);
    while(0==(I2C_I2CMasterStatus() & I2C_I2C_MSTAT_RD_CMPLT));
    tempTemperature.byte[TMP275_UNITSBYTE] = rxBuff[0];
    tempTemperature.byte[TMP275_FRACTIONBYTE] = rxBuff[1];
    
    return tempTemperature;
}


// Adapted from the NeoPixel library from Adafruit.
// Input a value 0 to 255 to get a color value.
// The colours are a transition r - g - b - back to r.
// Order seems to be BRG for the WS2812 driver for the PSoC 4
uint32_t Wheel(uint8_t WheelPos) {
    WheelPos = 255 - WheelPos;
    uint8_t R,G,B;
	if(WheelPos < 85) {
        R = 255 - WheelPos * 3;
        G = 0;
        B = WheelPos * 3;
        return (B<<16) | (R<<8) | G;
    } 
    else if(WheelPos < 170) {
        WheelPos -= 85;
        R = 0;
        G = WheelPos * 3;
        B = 255 - WheelPos * 3;
        return (B<<16) | (R<<8) | G;
    } 
    else {
        WheelPos -= 170;
        R = WheelPos * 3;
        G = 255 - WheelPos * 3;
        B = 0;
        return (B<<16) | (R<<8) | G;
    }
}

// SW1 enters the bootloader
CY_ISR(SW1_ISR){
    Bootloadable_Load();
}