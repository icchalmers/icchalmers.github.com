/*******************************************************************************
* File Name: LCDContrast_PM.c
* Version 2.0
*
* Description:
*  This file contains the setup, control, and status commands to support
*  the component operations in the low power mode.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "LCDContrast.h"

static LCDContrast_BACKUP_STRUCT LCDContrast_backup;


/*******************************************************************************
* Function Name: LCDContrast_SaveConfig
********************************************************************************
*
* Summary:
*  All configuration registers are retention. Nothing to save here.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void LCDContrast_SaveConfig(void)
{

}


/*******************************************************************************
* Function Name: LCDContrast_Sleep
********************************************************************************
*
* Summary:
*  Stops the component operation and saves the user configuration.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void LCDContrast_Sleep(void)
{
    if(0u != (LCDContrast_BLOCK_CONTROL_REG & LCDContrast_MASK))
    {
        LCDContrast_backup.enableState = 1u;
    }
    else
    {
        LCDContrast_backup.enableState = 0u;
    }

    LCDContrast_Stop();
    LCDContrast_SaveConfig();
}


/*******************************************************************************
* Function Name: LCDContrast_RestoreConfig
********************************************************************************
*
* Summary:
*  All configuration registers are retention. Nothing to restore here.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void LCDContrast_RestoreConfig(void)
{

}


/*******************************************************************************
* Function Name: LCDContrast_Wakeup
********************************************************************************
*
* Summary:
*  Restores the user configuration and restores the enable state.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void LCDContrast_Wakeup(void)
{
    LCDContrast_RestoreConfig();

    if(0u != LCDContrast_backup.enableState)
    {
        LCDContrast_Enable();
    }
}


/* [] END OF FILE */
