/*******************************************************************************
* File Name: LCDContrast.h
* Version 2.0
*
* Description:
*  This file provides constants and parameter values for the LCDContrast
*  component.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_TCPWM_LCDContrast_H)
#define CY_TCPWM_LCDContrast_H


#include "CyLib.h"
#include "cytypes.h"
#include "cyfitter.h"


/*******************************************************************************
* Internal Type defines
*******************************************************************************/

/* Structure to save state before go to sleep */
typedef struct
{
    uint8  enableState;
} LCDContrast_BACKUP_STRUCT;


/*******************************************************************************
* Variables
*******************************************************************************/
extern uint8  LCDContrast_initVar;


/***************************************
*   Conditional Compilation Parameters
****************************************/

#define LCDContrast_CY_TCPWM_V2                    (CYIPBLOCK_m0s8tcpwm_VERSION == 2u)
#define LCDContrast_CY_TCPWM_4000                  (CY_PSOC4_4000)

/* TCPWM Configuration */
#define LCDContrast_CONFIG                         (7lu)

/* Quad Mode */
/* Parameters */
#define LCDContrast_QUAD_ENCODING_MODES            (0lu)

/* Signal modes */
#define LCDContrast_QUAD_INDEX_SIGNAL_MODE         (0lu)
#define LCDContrast_QUAD_PHIA_SIGNAL_MODE          (3lu)
#define LCDContrast_QUAD_PHIB_SIGNAL_MODE          (3lu)
#define LCDContrast_QUAD_STOP_SIGNAL_MODE          (0lu)

/* Signal present */
#define LCDContrast_QUAD_INDEX_SIGNAL_PRESENT      (0lu)
#define LCDContrast_QUAD_STOP_SIGNAL_PRESENT       (0lu)

/* Interrupt Mask */
#define LCDContrast_QUAD_INTERRUPT_MASK            (1lu)

/* Timer/Counter Mode */
/* Parameters */
#define LCDContrast_TC_RUN_MODE                    (0lu)
#define LCDContrast_TC_COUNTER_MODE                (0lu)
#define LCDContrast_TC_COMP_CAP_MODE               (2lu)
#define LCDContrast_TC_PRESCALER                   (0lu)

/* Signal modes */
#define LCDContrast_TC_RELOAD_SIGNAL_MODE          (0lu)
#define LCDContrast_TC_COUNT_SIGNAL_MODE           (3lu)
#define LCDContrast_TC_START_SIGNAL_MODE           (0lu)
#define LCDContrast_TC_STOP_SIGNAL_MODE            (0lu)
#define LCDContrast_TC_CAPTURE_SIGNAL_MODE         (0lu)

/* Signal present */
#define LCDContrast_TC_RELOAD_SIGNAL_PRESENT       (0lu)
#define LCDContrast_TC_COUNT_SIGNAL_PRESENT        (0lu)
#define LCDContrast_TC_START_SIGNAL_PRESENT        (0lu)
#define LCDContrast_TC_STOP_SIGNAL_PRESENT         (0lu)
#define LCDContrast_TC_CAPTURE_SIGNAL_PRESENT      (0lu)

/* Interrupt Mask */
#define LCDContrast_TC_INTERRUPT_MASK              (1lu)

/* PWM Mode */
/* Parameters */
#define LCDContrast_PWM_KILL_EVENT                 (0lu)
#define LCDContrast_PWM_STOP_EVENT                 (0lu)
#define LCDContrast_PWM_MODE                       (4lu)
#define LCDContrast_PWM_OUT_N_INVERT               (0lu)
#define LCDContrast_PWM_OUT_INVERT                 (0lu)
#define LCDContrast_PWM_ALIGN                      (0lu)
#define LCDContrast_PWM_RUN_MODE                   (0lu)
#define LCDContrast_PWM_DEAD_TIME_CYCLE            (0lu)
#define LCDContrast_PWM_PRESCALER                  (0lu)

/* Signal modes */
#define LCDContrast_PWM_RELOAD_SIGNAL_MODE         (0lu)
#define LCDContrast_PWM_COUNT_SIGNAL_MODE          (3lu)
#define LCDContrast_PWM_START_SIGNAL_MODE          (0lu)
#define LCDContrast_PWM_STOP_SIGNAL_MODE           (0lu)
#define LCDContrast_PWM_SWITCH_SIGNAL_MODE         (0lu)

/* Signal present */
#define LCDContrast_PWM_RELOAD_SIGNAL_PRESENT      (0lu)
#define LCDContrast_PWM_COUNT_SIGNAL_PRESENT       (0lu)
#define LCDContrast_PWM_START_SIGNAL_PRESENT       (0lu)
#define LCDContrast_PWM_STOP_SIGNAL_PRESENT        (0lu)
#define LCDContrast_PWM_SWITCH_SIGNAL_PRESENT      (0lu)

/* Interrupt Mask */
#define LCDContrast_PWM_INTERRUPT_MASK             (0lu)


/***************************************
*    Initial Parameter Constants
***************************************/

/* Timer/Counter Mode */
#define LCDContrast_TC_PERIOD_VALUE                (65535lu)
#define LCDContrast_TC_COMPARE_VALUE               (65535lu)
#define LCDContrast_TC_COMPARE_BUF_VALUE           (65535lu)
#define LCDContrast_TC_COMPARE_SWAP                (0lu)

/* PWM Mode */
#define LCDContrast_PWM_PERIOD_VALUE               (65535lu)
#define LCDContrast_PWM_PERIOD_BUF_VALUE           (65535lu)
#define LCDContrast_PWM_PERIOD_SWAP                (0lu)
#define LCDContrast_PWM_COMPARE_VALUE              (0lu)
#define LCDContrast_PWM_COMPARE_BUF_VALUE          (65535lu)
#define LCDContrast_PWM_COMPARE_SWAP               (0lu)


/***************************************
*    Enumerated Types and Parameters
***************************************/

#define LCDContrast__LEFT 0
#define LCDContrast__RIGHT 1
#define LCDContrast__CENTER 2
#define LCDContrast__ASYMMETRIC 3

#define LCDContrast__X1 0
#define LCDContrast__X2 1
#define LCDContrast__X4 2

#define LCDContrast__PWM 4
#define LCDContrast__PWM_DT 5
#define LCDContrast__PWM_PR 6

#define LCDContrast__INVERSE 1
#define LCDContrast__DIRECT 0

#define LCDContrast__CAPTURE 2
#define LCDContrast__COMPARE 0

#define LCDContrast__TRIG_LEVEL 3
#define LCDContrast__TRIG_RISING 0
#define LCDContrast__TRIG_FALLING 1
#define LCDContrast__TRIG_BOTH 2

#define LCDContrast__INTR_MASK_TC 1
#define LCDContrast__INTR_MASK_CC_MATCH 2
#define LCDContrast__INTR_MASK_NONE 0
#define LCDContrast__INTR_MASK_TC_CC 3

#define LCDContrast__UNCONFIG 8
#define LCDContrast__TIMER 1
#define LCDContrast__QUAD 3
#define LCDContrast__PWM_SEL 7

#define LCDContrast__COUNT_UP 0
#define LCDContrast__COUNT_DOWN 1
#define LCDContrast__COUNT_UPDOWN0 2
#define LCDContrast__COUNT_UPDOWN1 3


/* Prescaler */
#define LCDContrast_PRESCALE_DIVBY1                ((uint32)(0u << LCDContrast_PRESCALER_SHIFT))
#define LCDContrast_PRESCALE_DIVBY2                ((uint32)(1u << LCDContrast_PRESCALER_SHIFT))
#define LCDContrast_PRESCALE_DIVBY4                ((uint32)(2u << LCDContrast_PRESCALER_SHIFT))
#define LCDContrast_PRESCALE_DIVBY8                ((uint32)(3u << LCDContrast_PRESCALER_SHIFT))
#define LCDContrast_PRESCALE_DIVBY16               ((uint32)(4u << LCDContrast_PRESCALER_SHIFT))
#define LCDContrast_PRESCALE_DIVBY32               ((uint32)(5u << LCDContrast_PRESCALER_SHIFT))
#define LCDContrast_PRESCALE_DIVBY64               ((uint32)(6u << LCDContrast_PRESCALER_SHIFT))
#define LCDContrast_PRESCALE_DIVBY128              ((uint32)(7u << LCDContrast_PRESCALER_SHIFT))

/* TCPWM set modes */
#define LCDContrast_MODE_TIMER_COMPARE             ((uint32)(LCDContrast__COMPARE         <<  \
                                                                  LCDContrast_MODE_SHIFT))
#define LCDContrast_MODE_TIMER_CAPTURE             ((uint32)(LCDContrast__CAPTURE         <<  \
                                                                  LCDContrast_MODE_SHIFT))
#define LCDContrast_MODE_QUAD                      ((uint32)(LCDContrast__QUAD            <<  \
                                                                  LCDContrast_MODE_SHIFT))
#define LCDContrast_MODE_PWM                       ((uint32)(LCDContrast__PWM             <<  \
                                                                  LCDContrast_MODE_SHIFT))
#define LCDContrast_MODE_PWM_DT                    ((uint32)(LCDContrast__PWM_DT          <<  \
                                                                  LCDContrast_MODE_SHIFT))
#define LCDContrast_MODE_PWM_PR                    ((uint32)(LCDContrast__PWM_PR          <<  \
                                                                  LCDContrast_MODE_SHIFT))

/* Quad Modes */
#define LCDContrast_MODE_X1                        ((uint32)(LCDContrast__X1              <<  \
                                                                  LCDContrast_QUAD_MODE_SHIFT))
#define LCDContrast_MODE_X2                        ((uint32)(LCDContrast__X2              <<  \
                                                                  LCDContrast_QUAD_MODE_SHIFT))
#define LCDContrast_MODE_X4                        ((uint32)(LCDContrast__X4              <<  \
                                                                  LCDContrast_QUAD_MODE_SHIFT))

/* Counter modes */
#define LCDContrast_COUNT_UP                       ((uint32)(LCDContrast__COUNT_UP        <<  \
                                                                  LCDContrast_UPDOWN_SHIFT))
#define LCDContrast_COUNT_DOWN                     ((uint32)(LCDContrast__COUNT_DOWN      <<  \
                                                                  LCDContrast_UPDOWN_SHIFT))
#define LCDContrast_COUNT_UPDOWN0                  ((uint32)(LCDContrast__COUNT_UPDOWN0   <<  \
                                                                  LCDContrast_UPDOWN_SHIFT))
#define LCDContrast_COUNT_UPDOWN1                  ((uint32)(LCDContrast__COUNT_UPDOWN1   <<  \
                                                                  LCDContrast_UPDOWN_SHIFT))

/* PWM output invert */
#define LCDContrast_INVERT_LINE                    ((uint32)(LCDContrast__INVERSE         <<  \
                                                                  LCDContrast_INV_OUT_SHIFT))
#define LCDContrast_INVERT_LINE_N                  ((uint32)(LCDContrast__INVERSE         <<  \
                                                                  LCDContrast_INV_COMPL_OUT_SHIFT))

/* Trigger modes */
#define LCDContrast_TRIG_RISING                    ((uint32)LCDContrast__TRIG_RISING)
#define LCDContrast_TRIG_FALLING                   ((uint32)LCDContrast__TRIG_FALLING)
#define LCDContrast_TRIG_BOTH                      ((uint32)LCDContrast__TRIG_BOTH)
#define LCDContrast_TRIG_LEVEL                     ((uint32)LCDContrast__TRIG_LEVEL)

/* Interrupt mask */
#define LCDContrast_INTR_MASK_TC                   ((uint32)LCDContrast__INTR_MASK_TC)
#define LCDContrast_INTR_MASK_CC_MATCH             ((uint32)LCDContrast__INTR_MASK_CC_MATCH)

/* PWM Output Controls */
#define LCDContrast_CC_MATCH_SET                   (0x00u)
#define LCDContrast_CC_MATCH_CLEAR                 (0x01u)
#define LCDContrast_CC_MATCH_INVERT                (0x02u)
#define LCDContrast_CC_MATCH_NO_CHANGE             (0x03u)
#define LCDContrast_OVERLOW_SET                    (0x00u)
#define LCDContrast_OVERLOW_CLEAR                  (0x04u)
#define LCDContrast_OVERLOW_INVERT                 (0x08u)
#define LCDContrast_OVERLOW_NO_CHANGE              (0x0Cu)
#define LCDContrast_UNDERFLOW_SET                  (0x00u)
#define LCDContrast_UNDERFLOW_CLEAR                (0x10u)
#define LCDContrast_UNDERFLOW_INVERT               (0x20u)
#define LCDContrast_UNDERFLOW_NO_CHANGE            (0x30u)

/* PWM Align */
#define LCDContrast_PWM_MODE_LEFT                  (LCDContrast_CC_MATCH_CLEAR        |   \
                                                         LCDContrast_OVERLOW_SET           |   \
                                                         LCDContrast_UNDERFLOW_NO_CHANGE)
#define LCDContrast_PWM_MODE_RIGHT                 (LCDContrast_CC_MATCH_SET          |   \
                                                         LCDContrast_OVERLOW_NO_CHANGE     |   \
                                                         LCDContrast_UNDERFLOW_CLEAR)
#define LCDContrast_PWM_MODE_ASYM                  (LCDContrast_CC_MATCH_INVERT       |   \
                                                         LCDContrast_OVERLOW_SET           |   \
                                                         LCDContrast_UNDERFLOW_CLEAR)

#if (LCDContrast_CY_TCPWM_V2)
    #if(LCDContrast_CY_TCPWM_4000)
        #define LCDContrast_PWM_MODE_CENTER                (LCDContrast_CC_MATCH_INVERT       |   \
                                                                 LCDContrast_OVERLOW_NO_CHANGE     |   \
                                                                 LCDContrast_UNDERFLOW_CLEAR)
    #else
        #define LCDContrast_PWM_MODE_CENTER                (LCDContrast_CC_MATCH_INVERT       |   \
                                                                 LCDContrast_OVERLOW_SET           |   \
                                                                 LCDContrast_UNDERFLOW_CLEAR)
    #endif /* (LCDContrast_CY_TCPWM_4000) */
#else
    #define LCDContrast_PWM_MODE_CENTER                (LCDContrast_CC_MATCH_INVERT       |   \
                                                             LCDContrast_OVERLOW_NO_CHANGE     |   \
                                                             LCDContrast_UNDERFLOW_CLEAR)
#endif /* (LCDContrast_CY_TCPWM_NEW) */

/* Command operations without condition */
#define LCDContrast_CMD_CAPTURE                    (0u)
#define LCDContrast_CMD_RELOAD                     (8u)
#define LCDContrast_CMD_STOP                       (16u)
#define LCDContrast_CMD_START                      (24u)

/* Status */
#define LCDContrast_STATUS_DOWN                    (1u)
#define LCDContrast_STATUS_RUNNING                 (2u)


/***************************************
*        Function Prototypes
****************************************/

void   LCDContrast_Init(void);
void   LCDContrast_Enable(void);
void   LCDContrast_Start(void);
void   LCDContrast_Stop(void);

void   LCDContrast_SetMode(uint32 mode);
void   LCDContrast_SetCounterMode(uint32 counterMode);
void   LCDContrast_SetPWMMode(uint32 modeMask);
void   LCDContrast_SetQDMode(uint32 qdMode);

void   LCDContrast_SetPrescaler(uint32 prescaler);
void   LCDContrast_TriggerCommand(uint32 mask, uint32 command);
void   LCDContrast_SetOneShot(uint32 oneShotEnable);
uint32 LCDContrast_ReadStatus(void);

void   LCDContrast_SetPWMSyncKill(uint32 syncKillEnable);
void   LCDContrast_SetPWMStopOnKill(uint32 stopOnKillEnable);
void   LCDContrast_SetPWMDeadTime(uint32 deadTime);
void   LCDContrast_SetPWMInvert(uint32 mask);

void   LCDContrast_SetInterruptMode(uint32 interruptMask);
uint32 LCDContrast_GetInterruptSourceMasked(void);
uint32 LCDContrast_GetInterruptSource(void);
void   LCDContrast_ClearInterrupt(uint32 interruptMask);
void   LCDContrast_SetInterrupt(uint32 interruptMask);

void   LCDContrast_WriteCounter(uint32 count);
uint32 LCDContrast_ReadCounter(void);

uint32 LCDContrast_ReadCapture(void);
uint32 LCDContrast_ReadCaptureBuf(void);

void   LCDContrast_WritePeriod(uint32 period);
uint32 LCDContrast_ReadPeriod(void);
void   LCDContrast_WritePeriodBuf(uint32 periodBuf);
uint32 LCDContrast_ReadPeriodBuf(void);

void   LCDContrast_WriteCompare(uint32 compare);
uint32 LCDContrast_ReadCompare(void);
void   LCDContrast_WriteCompareBuf(uint32 compareBuf);
uint32 LCDContrast_ReadCompareBuf(void);

void   LCDContrast_SetPeriodSwap(uint32 swapEnable);
void   LCDContrast_SetCompareSwap(uint32 swapEnable);

void   LCDContrast_SetCaptureMode(uint32 triggerMode);
void   LCDContrast_SetReloadMode(uint32 triggerMode);
void   LCDContrast_SetStartMode(uint32 triggerMode);
void   LCDContrast_SetStopMode(uint32 triggerMode);
void   LCDContrast_SetCountMode(uint32 triggerMode);

void   LCDContrast_SaveConfig(void);
void   LCDContrast_RestoreConfig(void);
void   LCDContrast_Sleep(void);
void   LCDContrast_Wakeup(void);


/***************************************
*             Registers
***************************************/

#define LCDContrast_BLOCK_CONTROL_REG              (*(reg32 *) LCDContrast_cy_m0s8_tcpwm_1__TCPWM_CTRL )
#define LCDContrast_BLOCK_CONTROL_PTR              ( (reg32 *) LCDContrast_cy_m0s8_tcpwm_1__TCPWM_CTRL )
#define LCDContrast_COMMAND_REG                    (*(reg32 *) LCDContrast_cy_m0s8_tcpwm_1__TCPWM_CMD )
#define LCDContrast_COMMAND_PTR                    ( (reg32 *) LCDContrast_cy_m0s8_tcpwm_1__TCPWM_CMD )
#define LCDContrast_INTRRUPT_CAUSE_REG             (*(reg32 *) LCDContrast_cy_m0s8_tcpwm_1__TCPWM_INTR_CAUSE )
#define LCDContrast_INTRRUPT_CAUSE_PTR             ( (reg32 *) LCDContrast_cy_m0s8_tcpwm_1__TCPWM_INTR_CAUSE )
#define LCDContrast_CONTROL_REG                    (*(reg32 *) LCDContrast_cy_m0s8_tcpwm_1__CTRL )
#define LCDContrast_CONTROL_PTR                    ( (reg32 *) LCDContrast_cy_m0s8_tcpwm_1__CTRL )
#define LCDContrast_STATUS_REG                     (*(reg32 *) LCDContrast_cy_m0s8_tcpwm_1__STATUS )
#define LCDContrast_STATUS_PTR                     ( (reg32 *) LCDContrast_cy_m0s8_tcpwm_1__STATUS )
#define LCDContrast_COUNTER_REG                    (*(reg32 *) LCDContrast_cy_m0s8_tcpwm_1__COUNTER )
#define LCDContrast_COUNTER_PTR                    ( (reg32 *) LCDContrast_cy_m0s8_tcpwm_1__COUNTER )
#define LCDContrast_COMP_CAP_REG                   (*(reg32 *) LCDContrast_cy_m0s8_tcpwm_1__CC )
#define LCDContrast_COMP_CAP_PTR                   ( (reg32 *) LCDContrast_cy_m0s8_tcpwm_1__CC )
#define LCDContrast_COMP_CAP_BUF_REG               (*(reg32 *) LCDContrast_cy_m0s8_tcpwm_1__CC_BUFF )
#define LCDContrast_COMP_CAP_BUF_PTR               ( (reg32 *) LCDContrast_cy_m0s8_tcpwm_1__CC_BUFF )
#define LCDContrast_PERIOD_REG                     (*(reg32 *) LCDContrast_cy_m0s8_tcpwm_1__PERIOD )
#define LCDContrast_PERIOD_PTR                     ( (reg32 *) LCDContrast_cy_m0s8_tcpwm_1__PERIOD )
#define LCDContrast_PERIOD_BUF_REG                 (*(reg32 *) LCDContrast_cy_m0s8_tcpwm_1__PERIOD_BUFF )
#define LCDContrast_PERIOD_BUF_PTR                 ( (reg32 *) LCDContrast_cy_m0s8_tcpwm_1__PERIOD_BUFF )
#define LCDContrast_TRIG_CONTROL0_REG              (*(reg32 *) LCDContrast_cy_m0s8_tcpwm_1__TR_CTRL0 )
#define LCDContrast_TRIG_CONTROL0_PTR              ( (reg32 *) LCDContrast_cy_m0s8_tcpwm_1__TR_CTRL0 )
#define LCDContrast_TRIG_CONTROL1_REG              (*(reg32 *) LCDContrast_cy_m0s8_tcpwm_1__TR_CTRL1 )
#define LCDContrast_TRIG_CONTROL1_PTR              ( (reg32 *) LCDContrast_cy_m0s8_tcpwm_1__TR_CTRL1 )
#define LCDContrast_TRIG_CONTROL2_REG              (*(reg32 *) LCDContrast_cy_m0s8_tcpwm_1__TR_CTRL2 )
#define LCDContrast_TRIG_CONTROL2_PTR              ( (reg32 *) LCDContrast_cy_m0s8_tcpwm_1__TR_CTRL2 )
#define LCDContrast_INTERRUPT_REQ_REG              (*(reg32 *) LCDContrast_cy_m0s8_tcpwm_1__INTR )
#define LCDContrast_INTERRUPT_REQ_PTR              ( (reg32 *) LCDContrast_cy_m0s8_tcpwm_1__INTR )
#define LCDContrast_INTERRUPT_SET_REG              (*(reg32 *) LCDContrast_cy_m0s8_tcpwm_1__INTR_SET )
#define LCDContrast_INTERRUPT_SET_PTR              ( (reg32 *) LCDContrast_cy_m0s8_tcpwm_1__INTR_SET )
#define LCDContrast_INTERRUPT_MASK_REG             (*(reg32 *) LCDContrast_cy_m0s8_tcpwm_1__INTR_MASK )
#define LCDContrast_INTERRUPT_MASK_PTR             ( (reg32 *) LCDContrast_cy_m0s8_tcpwm_1__INTR_MASK )
#define LCDContrast_INTERRUPT_MASKED_REG           (*(reg32 *) LCDContrast_cy_m0s8_tcpwm_1__INTR_MASKED )
#define LCDContrast_INTERRUPT_MASKED_PTR           ( (reg32 *) LCDContrast_cy_m0s8_tcpwm_1__INTR_MASKED )


/***************************************
*       Registers Constants
***************************************/

/* Mask */
#define LCDContrast_MASK                           ((uint32)LCDContrast_cy_m0s8_tcpwm_1__TCPWM_CTRL_MASK)

/* Shift constants for control register */
#define LCDContrast_RELOAD_CC_SHIFT                (0u)
#define LCDContrast_RELOAD_PERIOD_SHIFT            (1u)
#define LCDContrast_PWM_SYNC_KILL_SHIFT            (2u)
#define LCDContrast_PWM_STOP_KILL_SHIFT            (3u)
#define LCDContrast_PRESCALER_SHIFT                (8u)
#define LCDContrast_UPDOWN_SHIFT                   (16u)
#define LCDContrast_ONESHOT_SHIFT                  (18u)
#define LCDContrast_QUAD_MODE_SHIFT                (20u)
#define LCDContrast_INV_OUT_SHIFT                  (20u)
#define LCDContrast_INV_COMPL_OUT_SHIFT            (21u)
#define LCDContrast_MODE_SHIFT                     (24u)

/* Mask constants for control register */
#define LCDContrast_RELOAD_CC_MASK                 ((uint32)(LCDContrast_1BIT_MASK        <<  \
                                                                            LCDContrast_RELOAD_CC_SHIFT))
#define LCDContrast_RELOAD_PERIOD_MASK             ((uint32)(LCDContrast_1BIT_MASK        <<  \
                                                                            LCDContrast_RELOAD_PERIOD_SHIFT))
#define LCDContrast_PWM_SYNC_KILL_MASK             ((uint32)(LCDContrast_1BIT_MASK        <<  \
                                                                            LCDContrast_PWM_SYNC_KILL_SHIFT))
#define LCDContrast_PWM_STOP_KILL_MASK             ((uint32)(LCDContrast_1BIT_MASK        <<  \
                                                                            LCDContrast_PWM_STOP_KILL_SHIFT))
#define LCDContrast_PRESCALER_MASK                 ((uint32)(LCDContrast_8BIT_MASK        <<  \
                                                                            LCDContrast_PRESCALER_SHIFT))
#define LCDContrast_UPDOWN_MASK                    ((uint32)(LCDContrast_2BIT_MASK        <<  \
                                                                            LCDContrast_UPDOWN_SHIFT))
#define LCDContrast_ONESHOT_MASK                   ((uint32)(LCDContrast_1BIT_MASK        <<  \
                                                                            LCDContrast_ONESHOT_SHIFT))
#define LCDContrast_QUAD_MODE_MASK                 ((uint32)(LCDContrast_3BIT_MASK        <<  \
                                                                            LCDContrast_QUAD_MODE_SHIFT))
#define LCDContrast_INV_OUT_MASK                   ((uint32)(LCDContrast_2BIT_MASK        <<  \
                                                                            LCDContrast_INV_OUT_SHIFT))
#define LCDContrast_MODE_MASK                      ((uint32)(LCDContrast_3BIT_MASK        <<  \
                                                                            LCDContrast_MODE_SHIFT))

/* Shift constants for trigger control register 1 */
#define LCDContrast_CAPTURE_SHIFT                  (0u)
#define LCDContrast_COUNT_SHIFT                    (2u)
#define LCDContrast_RELOAD_SHIFT                   (4u)
#define LCDContrast_STOP_SHIFT                     (6u)
#define LCDContrast_START_SHIFT                    (8u)

/* Mask constants for trigger control register 1 */
#define LCDContrast_CAPTURE_MASK                   ((uint32)(LCDContrast_2BIT_MASK        <<  \
                                                                  LCDContrast_CAPTURE_SHIFT))
#define LCDContrast_COUNT_MASK                     ((uint32)(LCDContrast_2BIT_MASK        <<  \
                                                                  LCDContrast_COUNT_SHIFT))
#define LCDContrast_RELOAD_MASK                    ((uint32)(LCDContrast_2BIT_MASK        <<  \
                                                                  LCDContrast_RELOAD_SHIFT))
#define LCDContrast_STOP_MASK                      ((uint32)(LCDContrast_2BIT_MASK        <<  \
                                                                  LCDContrast_STOP_SHIFT))
#define LCDContrast_START_MASK                     ((uint32)(LCDContrast_2BIT_MASK        <<  \
                                                                  LCDContrast_START_SHIFT))

/* MASK */
#define LCDContrast_1BIT_MASK                      ((uint32)0x01u)
#define LCDContrast_2BIT_MASK                      ((uint32)0x03u)
#define LCDContrast_3BIT_MASK                      ((uint32)0x07u)
#define LCDContrast_6BIT_MASK                      ((uint32)0x3Fu)
#define LCDContrast_8BIT_MASK                      ((uint32)0xFFu)
#define LCDContrast_16BIT_MASK                     ((uint32)0xFFFFu)

/* Shift constant for status register */
#define LCDContrast_RUNNING_STATUS_SHIFT           (30u)


/***************************************
*    Initial Constants
***************************************/

#define LCDContrast_CTRL_QUAD_BASE_CONFIG                                                          \
        (((uint32)(LCDContrast_QUAD_ENCODING_MODES     << LCDContrast_QUAD_MODE_SHIFT))       |\
         ((uint32)(LCDContrast_CONFIG                  << LCDContrast_MODE_SHIFT)))

#define LCDContrast_CTRL_PWM_BASE_CONFIG                                                           \
        (((uint32)(LCDContrast_PWM_STOP_EVENT          << LCDContrast_PWM_STOP_KILL_SHIFT))   |\
         ((uint32)(LCDContrast_PWM_OUT_INVERT          << LCDContrast_INV_OUT_SHIFT))         |\
         ((uint32)(LCDContrast_PWM_OUT_N_INVERT        << LCDContrast_INV_COMPL_OUT_SHIFT))   |\
         ((uint32)(LCDContrast_PWM_MODE                << LCDContrast_MODE_SHIFT)))

#define LCDContrast_CTRL_PWM_RUN_MODE                                                              \
            ((uint32)(LCDContrast_PWM_RUN_MODE         << LCDContrast_ONESHOT_SHIFT))
            
#define LCDContrast_CTRL_PWM_ALIGN                                                                 \
            ((uint32)(LCDContrast_PWM_ALIGN            << LCDContrast_UPDOWN_SHIFT))

#define LCDContrast_CTRL_PWM_KILL_EVENT                                                            \
             ((uint32)(LCDContrast_PWM_KILL_EVENT      << LCDContrast_PWM_SYNC_KILL_SHIFT))

#define LCDContrast_CTRL_PWM_DEAD_TIME_CYCLE                                                       \
            ((uint32)(LCDContrast_PWM_DEAD_TIME_CYCLE  << LCDContrast_PRESCALER_SHIFT))

#define LCDContrast_CTRL_PWM_PRESCALER                                                             \
            ((uint32)(LCDContrast_PWM_PRESCALER        << LCDContrast_PRESCALER_SHIFT))

#define LCDContrast_CTRL_TIMER_BASE_CONFIG                                                         \
        (((uint32)(LCDContrast_TC_PRESCALER            << LCDContrast_PRESCALER_SHIFT))       |\
         ((uint32)(LCDContrast_TC_COUNTER_MODE         << LCDContrast_UPDOWN_SHIFT))          |\
         ((uint32)(LCDContrast_TC_RUN_MODE             << LCDContrast_ONESHOT_SHIFT))         |\
         ((uint32)(LCDContrast_TC_COMP_CAP_MODE        << LCDContrast_MODE_SHIFT)))
        
#define LCDContrast_QUAD_SIGNALS_MODES                                                             \
        (((uint32)(LCDContrast_QUAD_PHIA_SIGNAL_MODE   << LCDContrast_COUNT_SHIFT))           |\
         ((uint32)(LCDContrast_QUAD_INDEX_SIGNAL_MODE  << LCDContrast_RELOAD_SHIFT))          |\
         ((uint32)(LCDContrast_QUAD_STOP_SIGNAL_MODE   << LCDContrast_STOP_SHIFT))            |\
         ((uint32)(LCDContrast_QUAD_PHIB_SIGNAL_MODE   << LCDContrast_START_SHIFT)))

#define LCDContrast_PWM_SIGNALS_MODES                                                              \
        (((uint32)(LCDContrast_PWM_SWITCH_SIGNAL_MODE  << LCDContrast_CAPTURE_SHIFT))         |\
         ((uint32)(LCDContrast_PWM_COUNT_SIGNAL_MODE   << LCDContrast_COUNT_SHIFT))           |\
         ((uint32)(LCDContrast_PWM_RELOAD_SIGNAL_MODE  << LCDContrast_RELOAD_SHIFT))          |\
         ((uint32)(LCDContrast_PWM_STOP_SIGNAL_MODE    << LCDContrast_STOP_SHIFT))            |\
         ((uint32)(LCDContrast_PWM_START_SIGNAL_MODE   << LCDContrast_START_SHIFT)))

#define LCDContrast_TIMER_SIGNALS_MODES                                                            \
        (((uint32)(LCDContrast_TC_CAPTURE_SIGNAL_MODE  << LCDContrast_CAPTURE_SHIFT))         |\
         ((uint32)(LCDContrast_TC_COUNT_SIGNAL_MODE    << LCDContrast_COUNT_SHIFT))           |\
         ((uint32)(LCDContrast_TC_RELOAD_SIGNAL_MODE   << LCDContrast_RELOAD_SHIFT))          |\
         ((uint32)(LCDContrast_TC_STOP_SIGNAL_MODE     << LCDContrast_STOP_SHIFT))            |\
         ((uint32)(LCDContrast_TC_START_SIGNAL_MODE    << LCDContrast_START_SHIFT)))
        
#define LCDContrast_TIMER_UPDOWN_CNT_USED                                                          \
                ((LCDContrast__COUNT_UPDOWN0 == LCDContrast_TC_COUNTER_MODE)                  ||\
                 (LCDContrast__COUNT_UPDOWN1 == LCDContrast_TC_COUNTER_MODE))

#define LCDContrast_PWM_UPDOWN_CNT_USED                                                            \
                ((LCDContrast__CENTER == LCDContrast_PWM_ALIGN)                               ||\
                 (LCDContrast__ASYMMETRIC == LCDContrast_PWM_ALIGN))               
        
#define LCDContrast_PWM_PR_INIT_VALUE              (1u)
#define LCDContrast_QUAD_PERIOD_INIT_VALUE         (0x8000u)



#endif /* End CY_TCPWM_LCDContrast_H */

/* [] END OF FILE */
