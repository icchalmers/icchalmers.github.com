/*
 * Author: Iain Chalmers
 * Date: 2015/04/29
 * Copyright: Iain Chalmers 2015
 */

/* =============================================================================
 *
 * This is a program drive a 16x2 chartacter LCD display. It's designed to run
 * on a PCB that I designed. You can find the design files for the board on my 
 * FabAcademy 2015 webpage:
 *
 *     http://fabacademy.org/archives/2015/eu/students/chalmers.iain/week-11-outputs.html
 * 
 * Assuming everything is working OK, you should see "Waiting for input..." on 
 * the display, until new data is written to the I2C slave (address 0x08). 
 *
 * Memory address 0-99 is for Line 1, 100 to 199 is Line 2.
 * =============================================================================
*/

#include <project.h>
#include "stdio.h"

#define LCD_LINE_LENGTH 100
#define I2C_BUFFER_SIZE 255

uint8 I2CBuffer[250] = {0};
char line1Buffer[LCD_LINE_LENGTH + 1] = {[0 ... LCD_LINE_LENGTH] = ' '};
char line2Buffer[LCD_LINE_LENGTH + 1] = {[0 ... LCD_LINE_LENGTH] = ' '};
    
int main()
{   
    CyGlobalIntEnable;
    I2C_EzI2CSetBuffer1(I2C_BUFFER_SIZE, I2C_BUFFER_SIZE, I2CBuffer);
    I2C_Start();
    LCD_Start();
    LCDContrast_Start();

    uint32_t LEDFlag = 0;

    //ensure always 0 terminated string
    line1Buffer[100] = '\0';
    line2Buffer[100] = '\0';
        
    /* Set position for string output to row - 0 column - 0 */
    LCD_Position(0u, 0u);
    LCD_PrintString("Waiting for");
    LCD_Position(1u, 0u);
    LCD_PrintString("input...");
    
    while(1){

        if (0 != (I2C_EzI2CGetActivity() & I2C_EZI2C_STATUS_WRITE1)){  
            // Update the characters to show on the LCD
            // For now just displays the first 16 for each line
            // Probably more efficent to do some kind of memcpy...
            // Also pretty sloppy and not very extendable e.g. to 4 line LCD...
            
            // Update top line of the LCD
            uint32_t position;
            //  position 0 to 99 is LCD Line 1
            //  Only copy up to a null terminated string or 100 characters
            for(position = 0; (I2CBuffer[position] != '\0') && (position < 100); position++){
                line1Buffer[position] = I2CBuffer[position];
            }
            
            // Update bottom line of the LCD
            // position 100 to 199 is LCD Line 2
            // Only copy up to a null terminated string or 100 characters
            for(position = 100; (I2CBuffer[position] != '\0') && (position < 199); position++){
                line2Buffer[position-100] = I2CBuffer[position];
            }
            // write first line of LCD
            char tempBuff[17];
            tempBuff[16] = 0;
            for(position = 0; position < 16; position++){
                tempBuff[position] = line1Buffer[position];
            }
            LCD_Position(0, 0);
            LCD_PrintString(tempBuff);
            LCD_Position(1,0);
            for(position = 0; position < 16; position++){
                tempBuff[position] = line2Buffer[position];
            }
            LCD_PrintString(tempBuff);
            LEDPin_Write(LEDFlag);
            LEDFlag = !LEDFlag;            
        }
    }
}
