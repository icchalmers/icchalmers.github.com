THESE FILES ARE ALMOST CERTAINLY OUT OF DATE! 

It's also only a subset of the design files, as they are too big to all fit in the Fab Academy archive.

You should go to my GitHub and get the most up-to-date version from there!

http://github.com/icchalmers/WordClock_v2.0