package com.icchalmers.wordclock;

import android.graphics.Color;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ToggleButton;

import com.larswerkman.holocolorpicker.ColorPicker;
import com.larswerkman.holocolorpicker.SVBar;


public class MainActivity extends ActionBarActivity implements ColorPicker.OnColorChangedListener {

    private String hostAddress = "";
    private WordClock device;
    private View lcd_controls_view;
    private ColorPicker picker;
    private SVBar svBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lcd_controls_view = (View) findViewById(R.id.ui_lcd_controls);
        device = new WordClock();
        picker = (ColorPicker) findViewById(R.id.picker);
        svBar = (SVBar) findViewById(R.id.svbar);
        picker.addSVBar(svBar);
        picker.setOnColorChangedListener(this);

        // Disable UI controls
        setViewAndChildrenEnabled(lcd_controls_view, false);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void toggleLED(View view) {

        Log.d("WordClockLED", "Toggle button pressed");
        ToggleButton ledSwitch = (ToggleButton) findViewById(R.id.toggleLEDButton);
        if (ledSwitch.isChecked()) {
            Log.d("WordClockLED", "Turning LED on");
            device.setLED(true);
        } else {
            Log.d("WordClockLED", "Turning LED off");
            device.setLED(false);
        }
    }

    public void connectDisconnect(View view) {
        Log.d("WordClockConDis","Connection button pressed");
        Button connectButton = (Button) findViewById(R.id.connect_disconnect_button);
        EditText hostAddressText = (EditText) findViewById(R.id.edit_ip_address);

        ToggleButton ledSwitch = (ToggleButton) findViewById(R.id.toggleLEDButton);

        // Attempt to connect to the given host address
        // Enable/disable the LCD control UI based on connection success
        // Determining button behaviour based on it's text label is probably terrible practice...
        if (connectButton.getText().toString().contentEquals("Connect")) {
            Log.d("WordClockConDis", "Attempting to connect to " + hostAddressText.getText().toString());
            hostAddress = hostAddressText.getText().toString();
            device.setHostAddress(hostAddress);

            device.connect();

            // I need a way to block here until the async call in device finishes but
            // I can't find a quick way to do so and I've spent enough time on this
            // assignment as it is!


            if(device.connected){
                connectButton.setText("Disconnect");
                // Enable UI controls
                setViewAndChildrenEnabled(lcd_controls_view, true);
                Log.d("WordClockConDis", "I connected!");
            } else {
                Log.e("WordClockConDis", "I failed :(");
            }
        } else if (connectButton.getText().toString().contentEquals("Disconnect")) {
            Log.d("WordClockConDis", "Currently 'Disconnect'. Switching to 'Connect'");
            connectButton.setText("Connect");
            // Disable UI controls
            setViewAndChildrenEnabled(lcd_controls_view, false);
        }
    }

    // From user "Nightly Nexus" at http://stackoverflow.com/questions/7068873/how-can-i-disable-all-views-inside-the-layout
    private static void setViewAndChildrenEnabled(View view, boolean enabled) {
        view.setEnabled(enabled);
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                View child = viewGroup.getChildAt(i);
                setViewAndChildrenEnabled(child, enabled);
            }
        }
    }

    public void set_LED_colour(View view) {
        int colour = picker.getColor();
        picker.setOldCenterColor(colour);
        device.setLEDRGB(colour);
    }
    @Override
    public void onColorChanged(int colour) {
        //gives the color when it's changed.
        Log.d("WordClockColour", "Colour is" + colour);
        Log.d("WordClockColour", "    red: " + Color.red(colour) +
                " green: " + Color.green(colour) + " blue: " + Color.blue(colour));
    }
}
