package com.icchalmers.wordclock;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.View;

import com.loopj.android.http.AsyncHttpClient;

import com.loopj.android.http.TextHttpResponseHandler;

import org.apache.http.Header;

/**
 * Created by Iain on 29/06/2015.
 */
public class WordClock {
    public boolean connected;

    private String hostAddress;
    private static final AsyncHttpClient client = new AsyncHttpClient();
    private final String LED_ON_URL = "led?params=on";
    private final String LED_OFF_URL = "led?params=off";
    private final String SET_LED_RGB_URL = "RGB?params=";

    public void WordClock(){
        this.connected = false;
        this.client.setMaxRetriesAndTimeout(5,2000);
    }

    public void WordClock(String hostAddress) {
        this.WordClock();
        this.hostAddress = hostAddress;
    }

    public void setHostAddress(String hostAddress) {
        if (!hostAddress.startsWith("http://")) {
            hostAddress = "http://" + hostAddress;
        }
        if (!hostAddress.endsWith("/")) {
            hostAddress += "/";
        }
        this.hostAddress = hostAddress;
    }

    public void connect() {
        String connectionURL = hostAddress + "id";
        //final String CLOCK_URL = "http://192.168.1.21/id";
        //final String CLOCK_URL = "http://www.google.com";
        Log.d("WordClockCon", "Attempting connection to:  " + connectionURL);
        client.get(connectionURL,
                new TextHttpResponseHandler() {
                    @Override
                    public void onSuccess(int statusCode, Header[] headers, String responseBody) {
                        Log.d("WordClockCon", "Host responded! Response: " + responseBody.toString());
                        if (responseBody.toString().contains("wordclock")) {
                            connected = true;
                        }
                    }

                    @Override
                    public void onFailure(int statusCode, Header[] headers, String responseBody, Throwable error) {
                        if (responseBody == null) {
                            Log.e("WordClockCon", "Failed! TOTAL FAILURE!");
                        } else {
                            Log.e("WordClockCon", "Failed! Response: " + responseBody.toString());
                        }
                        connected = false;
                    }
                });
        return;
    }

    public void setLED(boolean state) {
        // Should check if connected...

        String command_url = hostAddress;
        if (state) {
            command_url += LED_ON_URL;
            Log.d("WordClockLED", "Attempting to turn on LED");
        }else {
            command_url += LED_OFF_URL;
            Log.d("WordClockLED", "Attempting to turn off LED");
        }

        client.get(command_url,
                new TextHttpResponseHandler() {
                    @Override
                    public void onSuccess(int statusCode, Header[] headers, String responseBody) {
                        Log.d("WordClockCon", "Host responded! Response: " + responseBody.toString());
                    }

                    @Override
                    public void onFailure(int statusCode, Header[] headers, String responseBody, Throwable error) {
                        if (responseBody == null) {
                            Log.e("WordClockCon", "Failed! TOTAL FAILURE!");
                        }else {
                            Log.e("WordClockCon", "Failed! Response: " + responseBody.toString());
                        }
                    }
                });
        return;
    }

    public void setLEDRGB(int colour) {
        // Should check if connected...

        String command_url = hostAddress + SET_LED_RGB_URL;
        int red = gammaCorrect(Color.red(colour));
        int green = gammaCorrect(Color.green(colour));
        int blue = gammaCorrect(Color.blue(colour));
        command_url += red + "," + green + "," + blue;
        Log.d("WordClockColour","Using URL: " + command_url);
        client.get(command_url,
                new TextHttpResponseHandler() {
                    @Override
                    public void onSuccess(int statusCode, Header[] headers, String responseBody) {
                        Log.d("WordClockColour", "Host responded! Response: " + responseBody.toString());
                    }

                    @Override
                    public void onFailure(int statusCode, Header[] headers, String responseBody, Throwable error) {
                        if (responseBody == null) {
                            Log.e("WordClockColour", "Failed! TOTAL FAILURE!");
                        } else {
                            Log.e("WordClockColour", "Failed! Response: " + responseBody.toString());
                        }
                    }
                });
    }

    private int gammaCorrect(int rawColour){
        // Used to apply a rudimentary gamma correction to compensate for
        // the human eye and also limit the LED brightness to 64/255 per channel
        return (int)(64*Math.pow((double)rawColour/255,(1/.45)));
    }
}
